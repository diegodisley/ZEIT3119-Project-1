To Create and Populate DB, follow instructions in group report.
The section is called "Script file for Database".

Run the SQL files in mySQL to make the database ready
Update the .env file with your relevent information (see report for further instructions)

When running on local host, follow "how to clone and run application locally" in the group report
